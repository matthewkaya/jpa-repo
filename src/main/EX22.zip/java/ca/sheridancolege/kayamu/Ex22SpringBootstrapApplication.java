package ca.sheridancolege.kayamu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ex22SpringBootstrapApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ex22SpringBootstrapApplication.class, args);
	}

}
